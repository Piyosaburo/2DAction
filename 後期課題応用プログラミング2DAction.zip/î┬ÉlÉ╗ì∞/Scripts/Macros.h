#pragma once

#define SCREEN_WIDTH (640)
#define SCREEN_HEIGHT (480)

#define GAME_END (-1)

#define START_INIT_SCENE (0)
#define START_UPDATE_SCENE (1)
#define GAME_INIT_SCENE (2)
#define GAME_UPDATE_SCENE (3)
#define FINISH_INIT_SCENE (4)
#define FINISH_UPDATE_SCENE (5)

#define STAGE_MAX_NUM (3)
#define STAGE0 (0)
#define STAGE1 (1)
#define STAGE2 (2)

#define CLEAR_ITEM_NUM (3)

#define CLEAR_NUM_FILE_NAME ("ClearNumFile.dat")

#define GAME_PLAY (0)
#define GAME_CLEAR (1)
#define GAME_PAUSE (2)
#define GAME_OVER (-1)

#define GRAVITY (9.8f)


//Player

#define PLAYER_START_POSITION_X (50)
#define PLAYER_START_POSITION_Y (300)

#define PLAYER_MAX_HP (10)
#define PLAYER_SIZE (32)
#define PLAYER_WALK_SPEED (3)
#define PLAYER_ANIME_SPEED (15) //�l���傫���قǒx���Ȃ�PLAYER_ANIME_SPEED
#define JUMP_POWER (10)

#define PLAYER_DIRECTION_UP (0)
#define PLAYER_DIRECTION_LEFT (4)
#define PLAYER_DIRECTION_DOWN (8)
#define PLAYER_DIRECTION_RIGHT (12)


//Map 

#define MAP_X_NUM (33)
#define MAP_Y_NUM (16)
#define MAPCHIP_ALL_NUM (9)
#define MAPCHIP_X_NUM (3)
#define MAPCHIP_Y_NUM (3)
#define MAPCHIP_SIZE (32)

#define MAPCHIP_GROUND_0 (0)
#define MAPCHIP_GROUND_1 (1)
#define MAPCHIP_GROUND_2 (2)
#define MAPCHIP_GROUND_6 (6)
#define MAPCHIP_MOVE (5)
#define MAPCHIP_ITEM (7)
#define MAPCHIP_GOAL (8)

#define MAPCHIP_MOVE_SPEED (1)

#define MAPCHIP_MOVE_RANGE_RIGHT (32)
#define MAPCHIP_MOVE_RANGE_LEFT (-32)


//GetItemEffect

#define GETITEMEFFECT_RADIUS_X (50)
#define GETITEMEFFECT_RADIUS_Y (25)

//Ghost

#define GHOST_SPEED (PLAYER_WALK_SPEED + 0.5f)