#pragma once
#include "Scene.h"

void FinishInit();
int FinishUpdate();
void FinishDraw();

