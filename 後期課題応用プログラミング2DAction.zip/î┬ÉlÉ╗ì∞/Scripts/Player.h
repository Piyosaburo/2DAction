#pragma once
#include "BasicInformation.h"
#include "Macros.h"
#include "Map.h"
#include "GetItemEffect.h"

class Player : public CharacterBasicInformation{
private:
	int playerTexture[16];
	int direction;
	int walkCount;
	bool jump;
	float jumpPower;
	bool isGround;
	int haveItemNum;
	int stageNum;
	bool beCaught; //���܂��Ă��邩
	Collision centerCol;
	Collision headCol;
	Collision legCol;
	Collision rightCol;
	Collision leftCol;
public:
	bool LoadTexture(const char*);
	void Init(bool,VECTOR,int);
	void Update(Map*,Camera*,GetItemEffect[],VECTOR,int*);
	void Draw(VECTOR);
	int GetHP();
	void AddDamage(int);
	void AddHaveItemNum(int);
	int GetHaveItemNum();
};
