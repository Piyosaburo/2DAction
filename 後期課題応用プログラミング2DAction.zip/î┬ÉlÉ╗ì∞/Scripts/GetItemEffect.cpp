#include "GetItemEffect.h"

bool GetItemEffect::LoadTexture(const char* effectImageName) {

	image = LoadGraph(effectImageName, true);

	if (image == -1) {
		return false;
	}

	return true;
}

void GetItemEffect::Init(bool e) {
	exist = e;
	radius.x = GETITEMEFFECT_RADIUS_X;
	radius.y = GETITEMEFFECT_RADIUS_Y;
	size = 10.0f;
	count = 0;
}

void GetItemEffect::Update(VECTOR playerPos) {

	if (exist == false) {
		return;
	}

	pos.x = playerPos.x + cosf(count) * radius.x;
	pos.y = playerPos.y + sinf(count) * radius.y;

	radius.x *= 0.98f;
	radius.y *= 0.98f;
	size *= 0.98f;

	if (size < 1.0f) {
		exist = false;
	}

	count++;
}

void GetItemEffect::Draw(VECTOR cameraPos) {

	if (exist == false) {
		return;
	}

	DrawCircle(pos.x - cameraPos.x, pos.y, size, GetColor(0, 0, 255), true);
}

bool GetItemEffect::GetExist() {
	return exist;
}