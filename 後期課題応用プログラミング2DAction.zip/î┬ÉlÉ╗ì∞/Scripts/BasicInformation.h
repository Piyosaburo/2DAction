#pragma once

#include"DxLib.h"
#include "Macros.h"
#include <math.h>
#include "Collision.h"

class Vec2 {
public:
	Vec2(float x, float y) : x(x), y(y) {}
	float x;
	float y;
};


class Camera {
	VECTOR pos;
	int limitPosX;
public:

	void Init(VECTOR p, int lpx)
	{
		pos = p;
		limitPosX = lpx;
	}

	VECTOR GetPos() {
		return pos;
	}

	void SetPos(VECTOR p) {
		pos = p;
	}

	void AddPos(VECTOR add) {
		pos.x += add.x;
		pos.y += add.y;
	}

	void Update() {

		if (pos.x < 0) {
			pos.x = 0;
		}

		if (pos.x > limitPosX - SCREEN_WIDTH - MAPCHIP_SIZE / 2) {
			pos.x = limitPosX - SCREEN_WIDTH - MAPCHIP_SIZE / 2;
		}

	}
};

class CharacterBasicInformation {
protected:
	bool exist;
	int HP;
	VECTOR pos;
	VECTOR size;
	//VECTOR imageSize;
public:

	VECTOR GetPos() {
		return pos;
	}

	VECTOR GetSize() {
		return size;
	}

	void SetExist(bool e) {
		exist = e;
	}

	bool GetExist() {
		return exist;
	}
};

