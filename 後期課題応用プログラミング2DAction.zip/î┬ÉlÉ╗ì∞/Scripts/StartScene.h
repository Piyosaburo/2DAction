#pragma once
#include "DxLib.h"
#include "Scene.h"
#include "Macros.h"
#include "ClearNumFile.h"
#include <math.h>

bool StartLoadTexture(const char*,const char*);
void StartInit();
int StartUpdate(int*);
void StartDraw();