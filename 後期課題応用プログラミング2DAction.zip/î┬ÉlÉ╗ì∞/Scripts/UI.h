#pragma once
#include "DxLib.h"

class UI{

	float timeLimit;
	int image;
	int itemImage;
	int clearTextImage;
	int dieTextImage;
	//VECTOR imageSize;
public:
	bool LoadTexture(const char*,const char*,const char*);
	void Init();
	void Update(float);
	void Draw(int,int, int);
	//void Draw(float,int,int,int);

};