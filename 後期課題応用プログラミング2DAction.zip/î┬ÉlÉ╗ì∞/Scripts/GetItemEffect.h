#pragma once
#include "DxLib.h"
#include <math.h>
#include "Macros.h"

class GetItemEffect {
private:
	bool exist;
	VECTOR pos;
	VECTOR radius;
	float size;
	int image;
	int count;
	//float animeCount;
	//float animeSpeed;
public:
	bool LoadTexture(const char*);
	void Init(bool);
	void Update(VECTOR);
	void Draw(VECTOR);
	bool GetExist();
};

