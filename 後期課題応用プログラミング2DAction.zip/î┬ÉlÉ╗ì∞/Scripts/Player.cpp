#pragma once


#include "Player.h"

//col = player�̓����蔻��̈ʒu
//map = map
//hitBloclPos = ���������u���b�N�̈ʒu
//blockNum = �u���b�N�̎��
//moveVec = ���������u���b�N�̈ړ��� (�����u���b�N�̂���)

bool Player::LoadTexture(const char* textureName) {

	if (LoadDivGraph(textureName, 16, 4, 4, PLAYER_SIZE, PLAYER_SIZE, playerTexture, TRUE) == -1) {
		return false;
	}

	return true;
}

void Player::Init(bool e,VECTOR p,int sn) {
	exist = e;
	stageNum = sn;
	pos = p;
	direction = PLAYER_DIRECTION_RIGHT;
	walkCount = 0;
	jump = false;
	jumpPower = 0;
	isGround = false;
	size.x = PLAYER_SIZE;
	size.y = PLAYER_SIZE;
	beCaught = false;
	haveItemNum = stageNum * 3;
}

void Player::Update(Map* map, Camera* camera,GetItemEffect getItemEffect[],VECTOR ghostPos, int* game) {

	if (*game != GAME_PLAY) {
		return;
	}


	VECTOR p = pos;
	VECTOR moveVec = { 0,0 };
	VECTOR addStagePos = { 0,0 };

	if (GetAsyncKeyState('A')) {

		moveVec.x -= PLAYER_WALK_SPEED;

		walkCount += PLAYER_WALK_SPEED;
		direction = PLAYER_DIRECTION_LEFT;
	}

	if (GetAsyncKeyState('D')) {

		moveVec.x += PLAYER_WALK_SPEED;

		walkCount += PLAYER_WALK_SPEED;
		direction = PLAYER_DIRECTION_RIGHT;
	}

	if (GetAsyncKeyState('W') && isGround == true) {
		jumpPower = JUMP_POWER;
		jump = true;
	}

	if (jump == true) {
		moveVec.y -= jumpPower;
		jumpPower -= GRAVITY / 10;

		if (jumpPower <= 0) {
			jump = false;
		}
	}
	else {
		moveVec.y += GRAVITY;
	}

	pos.x += moveVec.x;
	pos.y += moveVec.y;

	headCol.SetCollision(pos.x, pos.y - size.y / 2, PLAYER_SIZE / 2 - 2, 2);
	legCol.SetCollision(pos.x, pos.y + size.y / 2, PLAYER_SIZE / 2 - 2, 2);


	VECTOR hitBlockPos = { 0,0 };
	int blockNum = 0;
	VECTOR blockMoveVec = { 0,0 };


	if (HitMap(headCol, *map, &hitBlockPos, &blockNum, &blockMoveVec) == true) {

		if (blockNum == MAPCHIP_MOVE) {
			pos.y = (hitBlockPos.y + MAPCHIP_SIZE / 2) + (size.y / 2);
			jump = false;
		}
		else if (blockNum == MAPCHIP_GROUND_0 || blockNum == MAPCHIP_GROUND_1 || blockNum == MAPCHIP_GROUND_2 || blockNum == MAPCHIP_GROUND_6) {
			pos.y = (hitBlockPos.y + MAPCHIP_SIZE / 2) + (size.y / 2);
			jump = false;
		}
	}

	isGround = false;

	if (HitMap(legCol, *map, &hitBlockPos, &blockNum, &blockMoveVec) == true) {

		if (blockNum == MAPCHIP_MOVE) {
			pos.x = pos.x + blockMoveVec.x;
			pos.y = (hitBlockPos.y - MAPCHIP_SIZE / 2) - (size.y / 2);
			isGround = true;
		}
		else if (blockNum == MAPCHIP_GROUND_0 || blockNum == MAPCHIP_GROUND_1 || blockNum == MAPCHIP_GROUND_2 || blockNum == MAPCHIP_GROUND_6) {
			pos.y = (hitBlockPos.y - MAPCHIP_SIZE / 2) - (size.y / 2);
			isGround = true;
		}

	}
	else {

	}


	rightCol.SetCollision(pos.x + size.x / 3, pos.y, 2, 30);
	leftCol.SetCollision(pos.x - size.x / 3, pos.y, 2, 30);

	if (HitMap(rightCol, *map, &hitBlockPos, &blockNum, &blockMoveVec) == true) {
		if (blockNum == MAPCHIP_GROUND_0 || blockNum == MAPCHIP_GROUND_1 ||
			blockNum == MAPCHIP_GROUND_2 || blockNum == MAPCHIP_GROUND_6) {
			pos.x = (hitBlockPos.x - MAPCHIP_SIZE / 2) - (size.x / 3);
		}
		else if (blockNum == MAPCHIP_MOVE) {
			pos.x = (hitBlockPos.x - MAPCHIP_SIZE / 2) - (size.x / 3) + blockMoveVec.x; //blockMoveVec.x ���v���X�Ȃ̂͒��g���}�C�i�X�ɂȂ邩��
		}
	}

	if (HitMap(leftCol, *map, &hitBlockPos, &blockNum, &blockMoveVec) == true) {
		if (blockNum == MAPCHIP_GROUND_0 || blockNum == MAPCHIP_GROUND_1 ||
			blockNum == MAPCHIP_GROUND_2 || blockNum == MAPCHIP_GROUND_6) {
			pos.x = (hitBlockPos.x + MAPCHIP_SIZE / 2) + (size.x / 3);
		}
		else if (blockNum == MAPCHIP_MOVE) {
			pos.x = (hitBlockPos.x + MAPCHIP_SIZE / 2) + (size.x / 3) + blockMoveVec.x;
		}
	}


	centerCol.SetCollision(pos.x, pos.y, 2, 2);

	if (HitMap(centerCol, *map, &hitBlockPos, &blockNum, &blockMoveVec) == true) {
		if (blockNum == MAPCHIP_GROUND_0 || blockNum == MAPCHIP_GROUND_1 || blockNum == MAPCHIP_GROUND_2 || blockNum == MAPCHIP_GROUND_6 ||
			blockNum == MAPCHIP_MOVE) {
			beCaught = true;
		}
		else {

		}
	}
	

	if (HitItem(centerCol, map) == true) {
		AddHaveItemNum(1);

		for (int i = 0; i < 3; i++) {
			if (getItemEffect[i].GetExist() == false) {
				getItemEffect[i].Init(true);
				break;
			}
		}
	}

	if (beCaught == true) {
		*game = GAME_OVER;
		return;
	}

	if (GetHaveItemNum() >= CLEAR_ITEM_NUM * (stageNum + 1)) {
		if (Goal(centerCol, map) == true) {
			*game = GAME_CLEAR;
			return;
		}
	}


	VECTOR v = { ghostPos.x - pos.x,ghostPos.y - pos.y };
	float radius = sqrtf(v.x * v.x + v.y * v.y);

	if (radius < 10) {
		*game = GAME_OVER;
		return;
	}


	VECTOR addCameraPos = { 0,0 };
	int d = direction == PLAYER_DIRECTION_RIGHT ? 1 : -1;

	if (pos.x + moveVec.x < camera->GetPos().x + 200) {
		addCameraPos = { moveVec.x * -d,0 };
	}
	if (pos.x + moveVec.x > camera->GetPos().x + 440) {
		addCameraPos = { moveVec.x * d,0 };
	}

	camera->AddPos(addCameraPos);
}

void Player::Draw(VECTOR cameraPos) {

	DrawGraph(pos.x - PLAYER_SIZE / 2 - cameraPos.x, pos.y - PLAYER_SIZE / 2, playerTexture[direction + (walkCount / PLAYER_ANIME_SPEED % 4)], TRUE);

	//DrawBox(headCol.pos.x - (headCol.size.x / 2) - cameraPos.x, headCol.pos.y, headCol.pos.x + (headCol.size.x / 2) - cameraPos.x, headCol.pos.y - headCol.size.y, GetColor(255, 255, 0), false);
	//DrawBox(legCol.pos.x - (legCol.size.x / 2) - cameraPos.x, legCol.pos.y, legCol.pos.x + (legCol.size.x / 2) - cameraPos.x, legCol.pos.y + legCol.size.y, GetColor(255, 255, 0), false);
	//DrawBox(rightCol.pos.x - cameraPos.x, rightCol.pos.y - (rightCol.size.y / 2), rightCol.pos.x + rightCol.size.x - cameraPos.x, rightCol.pos.y + (rightCol.size.y / 2), GetColor(255, 255, 0), false);
	//DrawBox(leftCol.pos.x - cameraPos.x, leftCol.pos.y - (leftCol.size.y / 2), leftCol.pos.x + leftCol.size.x - cameraPos.x, leftCol.pos.y + (leftCol.size.y / 2), GetColor(255, 255, 0), false);
	//DrawBox(centerCol.pos.x - cameraPos.x, centerCol.pos.y, centerCol.pos.x + centerCol.size.x - cameraPos.x, centerCol.pos.y + centerCol.size.y, GetColor(255, 255, 0), false);
}

int Player::GetHP() {
	return HP;
}

void Player::AddDamage(int damage) {
	HP -= damage;
}

void Player::AddHaveItemNum(int add) {
	haveItemNum += add;
}
int Player::GetHaveItemNum() {
	return haveItemNum;
}

