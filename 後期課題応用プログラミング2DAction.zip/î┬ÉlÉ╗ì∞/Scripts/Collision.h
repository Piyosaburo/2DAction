#pragma once
#include "DxLib.h"
#include <math.h>


class Collision {
public:
	VECTOR pos;
	VECTOR size;
	void SetCollision(float posX, float posY, float sizeX, float sizeY) {
		pos.x = posX;
		pos.y = posY;
		size.x = sizeX;
		size.y = sizeY;
	}
};

extern bool HitCircle(VECTOR pos0, float radius0, VECTOR pos1, float radius1);

