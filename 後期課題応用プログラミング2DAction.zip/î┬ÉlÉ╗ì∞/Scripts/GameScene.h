#pragma once
#include "Scene.h"
#include "ClearNumFile.h"

bool GameInit(int);
int GameUpdate();
void GameDraw();