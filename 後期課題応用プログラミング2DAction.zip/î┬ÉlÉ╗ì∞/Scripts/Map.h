#pragma once

#include "BasicInformation.h"

class Block {
private:
	int blockNumber;
	VECTOR pos = { 0,0 };

	//�����u���b�N�̂��߂̏��
	int direction; //-1:left 1:right
	VECTOR moveVector; //1�t���[���ł̈ړ���
	VECTOR allMoveVector; //���܂ł̈ړ���
public:
	void Init(int n,VECTOR p) {
		blockNumber = n;
		pos = p;
		direction = 1;
		moveVector = { 0,0 };
		allMoveVector = { 0,0 };
	}

	void Update() {
		if (blockNumber == MAPCHIP_MOVE) {

			VECTOR add = { MAPCHIP_MOVE_SPEED * direction,0 };

			AddPos(add);

			if (GetAllMoveVector().x > MAPCHIP_MOVE_RANGE_RIGHT || GetAllMoveVector().x < MAPCHIP_MOVE_RANGE_LEFT) {
				direction *= -1;
			}
		}
	}

	int GetBlockNumber() {
		return blockNumber;
	}

	VECTOR GetPos() {
		return pos;
	}

	void AddPos(VECTOR addPos) {
		pos.x += addPos.x;
		pos.y += addPos.y;

		SetMoveVector(addPos);

	}

	void SetMoveVector(VECTOR add) {
		moveVector = add;
		AddAllMoveVector(add);
	}

	VECTOR GetMocvVector() {
		return moveVector;
	}

	void AddAllMoveVector(VECTOR add) {
		allMoveVector.x += add.x;
		allMoveVector.y += add.y;
	}

	VECTOR GetAllMoveVector() {
		return allMoveVector;
	}

	void SetBlockNumber(int n) {
		blockNumber = n;
	}
};

class Map{
private:
	int stageNum;
	int mapTexture[MAPCHIP_ALL_NUM];
	VECTOR stagePos;
public:

	Block mapChip[MAP_Y_NUM][MAP_X_NUM];

	void Init(int,VECTOR);
	bool LoadTexture(const char*);
	void Update();
	void Draw(VECTOR);
};



extern bool HitMap(Collision col, Map map, VECTOR* hitBlockPos, int* blockNum, VECTOR* moveVec);
extern bool Goal(Collision col, Map* map);
extern bool HitItem(Collision, Map*);