#include "Ghost.h"

bool Ghost::LoadTexture(const char* ghostTextureName) {
	image = LoadGraph(ghostTextureName, true);

	if (image == -1) {
		return false;
	}

	return true;
}

void Ghost::Init(bool e, VECTOR p) {
	exist = e;
	pos = p;
}

void Ghost::Update(VECTOR playerPos) {

	if (exist == false) {
		return;
	}
	
	playerPos;

	VECTOR v = { playerPos.x - pos.x,playerPos.y - pos.y };
	float l = sqrtf(v.x * v.x + v.y * v.y);
	VECTOR s = { v.x / l * GHOST_SPEED,v.y / l * GHOST_SPEED };

	pos.x += s.x;
	pos.y += s.y;

	if (v.x >= 0) {
		rota = true;
	}
	else {
		rota = false;
	}
}

void Ghost::Draw(VECTOR cameraPos) {

	if (exist == false) {
		return;
	}

	DrawRotaGraph(pos.x - cameraPos.x, pos.y, 0.075f, 0, image, true, rota);
}