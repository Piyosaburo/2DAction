#include "StartScene.h"

int selectNum;
int clearNum;
int startSceneImage;
int itemImage1;
int timer;

bool StartLoadTexture(const char* startSceneTextureName, const char* itemTextureName) {

	startSceneImage = LoadGraph(startSceneTextureName, true);

	if (startSceneImage == -1) {
		return false;
	}

	itemImage1 = LoadGraph(itemTextureName, true);

	if (itemImage1 == -1) {
		return false;
	}

	return true;
}

void StartInit() {

	selectNum = 0;

	clearNum = LoadClearNum();

	timer = 0;

	SetFontSize(25);
}

int StartUpdate(int* stage) {

	if (GetAsyncKeyState(VK_UP) && pushedUpKey == false) {
		selectNum++;
		pushedUpKey = true;
	}
	else if (!GetAsyncKeyState(VK_UP)) {
		pushedUpKey = false;
	}

	if (GetAsyncKeyState(VK_DOWN) && pushedDownKey == false) {
		selectNum--;
		pushedDownKey = true;
	}
	else if (!GetAsyncKeyState(VK_DOWN)) {
		pushedDownKey = false;
	}

	if (selectNum < GAME_END) {
		selectNum = GAME_END;
	}

	if (selectNum > 0) {
		selectNum = 0;
	}

	if (GetAsyncKeyState(VK_RETURN) && pushedEnterKey == false) {

		pushedEnterKey = true;

		if (selectNum == GAME_END) {
			return GAME_END;
		}
		
		if (clearNum >= STAGE_MAX_NUM) {
			clearNum = 0;
			SaveClearNum(clearNum);
			return START_INIT_SCENE;
		}
		else {

			*stage = clearNum;
			return GAME_INIT_SCENE;
		}
	}

	if (!GetAsyncKeyState(VK_RETURN)) {

		pushedEnterKey = false;
	}

	timer++;

	return START_UPDATE_SCENE;
}

void StartDraw() {

	DrawGraph(0, 0, startSceneImage, true);

	for (float i = 0, scale = 0.5f; i < 360; i += 360 / 9, scale *= 1.2f) {

		VECTOR p = { 320 + cosf(i * 3.14159f / 180.0f) * i,240 + sinf(i * 3.14159f / 180.0f) * i };

		DrawExtendGraph(p.x, p.y, p.x + 32 * scale, p.y + 32 * scale, itemImage1, true);
	}

	const char* selectStageStr = "///";

	switch (clearNum)
	{
	case 0:
		selectStageStr = "���̕�";
		break;
	case 1:
		selectStageStr = "�[���̕�";
		break;
	case 2:
		selectStageStr = "��̕�";
		break;
	default:
		selectStageStr = "�͂��߂���";
		break;
	}

	if (selectNum == 0) {
		DrawFormatString(50, 300, GetColor(255, 255, 255), "��%s", selectStageStr);
		DrawFormatString(50, 350, GetColor(255, 255, 255), "�I��");
	}
	else if (selectNum == GAME_END) {
		DrawFormatString(50, 300, GetColor(255, 255, 255), "%s", selectStageStr);
		DrawFormatString(50, 350, GetColor(255, 255, 255), "���I��");
	}
}