#include "UI.h"
#include "Macros.h"
#include "Scene.h"

bool UI::LoadTexture(const char* itemTextureName,const char* clearTextTextureName,const char* dieTextTextureName) {
	itemImage = LoadGraph(itemTextureName, true);

	if (itemImage == -1) {
		return false;
	}

	clearTextImage = LoadGraph(clearTextTextureName, true);

	if (clearTextImage == -1) {
		return false;
	}

	dieTextImage = LoadGraph(dieTextTextureName, true);

	if (dieTextImage == -1) {
		return false;
	}

	return true;
}

void UI::Init() {

}

void UI::Update(float timer) {



}

void UI::Draw(int haveItemNum, int gameState, int pauseSelectNum) {

	for (int i = 0; i < haveItemNum; i++) {
		DrawGraph(i * 32, 0, itemImage, true);
	}


	switch (gameState)
	{
	case GAME_PAUSE:
		if (pauseSelectNum == 0) {
			DrawFormatString(100, 200, GetColor(255, 255, 255), "���ĊJ");
			DrawFormatString(100, 250, GetColor(255, 255, 255), "�I��");
		}
		else if (pauseSelectNum == 1) {
			DrawFormatString(100, 200, GetColor(255, 255, 255), "�ĊJ");
			DrawFormatString(100, 250, GetColor(255, 255, 255), "���I��");
		}
		break;

	case GAME_CLEAR:
		DrawGraph(200, 200, clearTextImage, true);
		break;

	case GAME_OVER:
		DrawGraph(200, 200, dieTextImage, true);
		break;
	}
}
