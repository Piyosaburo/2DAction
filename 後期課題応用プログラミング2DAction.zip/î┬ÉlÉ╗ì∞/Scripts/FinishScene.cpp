#pragma once
#include "FinishScene.h"
#include "Macros.h"


void FinishInit() {

}

int FinishUpdate() {

	if (GetAsyncKeyState(VK_RETURN) && pushedEnterKey == false) {
		pushedEnterKey = true;
		return START_INIT_SCENE;
	}

	return FINISH_UPDATE_SCENE;
}

void FinishDraw() {
	DrawFormatString(0, 0, GetColor(255, 255, 255), "FinishScene");
}