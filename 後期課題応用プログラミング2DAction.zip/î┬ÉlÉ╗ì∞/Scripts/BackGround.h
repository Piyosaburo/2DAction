#pragma once

#include "DxLib.h"
#include "Macros.h"

class BackGround {
private:
	int stageNum;
	int backgroundImage;
	int foregroundImage;
public:
	bool LoadTexture(const char*, const char*);
	void Init(int);
	void BackGroundDraw();
	void ForeGroundDraw();
};