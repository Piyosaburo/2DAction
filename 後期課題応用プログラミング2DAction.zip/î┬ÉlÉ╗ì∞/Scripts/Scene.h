#pragma once
#include "StartScene.h"
#include "GameScene.h"
#include "FinishScene.h"


void SceneInit();
bool SceneUpdate();
void SceneDraw();

extern bool pushedEnterKey;
extern bool pushedUpKey;
extern bool pushedDownKey;