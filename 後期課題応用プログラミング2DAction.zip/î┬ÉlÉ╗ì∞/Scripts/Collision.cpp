#include "Collision.h"

bool HitCircle(VECTOR pos0, float radius0, VECTOR pos1, float radius1)
{
	VECTOR p = { pos1.x - pos0.x,pos1.y - pos0.y };
	float r = radius0 + radius1;


	if (p.x * p.x + p.y * p.y <= r * r) {
		return true;
	}

	return false;
}