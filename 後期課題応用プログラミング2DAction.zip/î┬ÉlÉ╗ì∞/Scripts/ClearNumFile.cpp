#include "ClearNumFile.h"

int LoadClearNum() {

	FILE* file;
	int clearNum = 0;

	fopen_s(&file, CLEAR_NUM_FILE_NAME, "rb");

	if (file != NULL) {

		fscanf_s(file, "%d", &clearNum);
	}
	else {
		fopen_s(&file, CLEAR_NUM_FILE_NAME, "wb");
		fprintf_s(file, "%d", clearNum);
	}


	fclose(file);

	return clearNum;
}


void SaveClearNum(int clearNum) {

	FILE* file;

	fopen_s(&file, CLEAR_NUM_FILE_NAME, "wb");
	fprintf_s(file, "%d", clearNum);

	fclose(file);
}