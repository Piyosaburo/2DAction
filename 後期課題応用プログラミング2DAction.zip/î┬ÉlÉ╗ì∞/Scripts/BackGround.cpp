#include"BackGround.h"

bool BackGround::LoadTexture(const char* backgroundTextureName, const char* foregroundTextureName) {

	backgroundImage = LoadGraph(backgroundTextureName, true);

	foregroundImage = LoadGraph(foregroundTextureName, true);

	if (backgroundImage == -1 || foregroundImage == -1) {
		return false;
	}

	return true;
}

void BackGround::Init(int sn) {
	stageNum = sn;
}

void BackGround::BackGroundDraw() {

	DrawGraph(stageNum * -640, 0, backgroundImage, true);

}

void BackGround::ForeGroundDraw() {

	if (stageNum != STAGE2) {
		return;
	}

	DrawGraph(0, 0, foregroundImage, true);
}