#pragma once
#include "Scene.h"
#include "Macros.h"

int scene;
int stage;
bool pushedEnterKey;
bool pushedUpKey;
bool pushedDownKey;

void SceneInit() {
	StartLoadTexture("Images/StartScene.png", "Images/Item.png");
	scene = START_INIT_SCENE;
}

bool SceneUpdate() {

	switch (scene)
	{

	case START_INIT_SCENE:
		StartInit();
		scene = START_UPDATE_SCENE;
		break;
		
	case START_UPDATE_SCENE:
		scene = StartUpdate(&stage);
		break;

	case GAME_INIT_SCENE:
		scene = GameInit(stage) == true ? GAME_UPDATE_SCENE : GAME_END;
		break;

	case GAME_UPDATE_SCENE:
		scene = GameUpdate();

		break;

	case FINISH_INIT_SCENE:
		FinishInit();
		scene = FINISH_UPDATE_SCENE;
		break;


	case FINISH_UPDATE_SCENE:
		scene = FinishUpdate();
		break;

	case GAME_END:
		return false;
		break;

	default:
		break;
	}

	return true;
}

void SceneDraw() {

	switch (scene)
	{

	case START_UPDATE_SCENE:
		StartDraw();
		break;

	case GAME_UPDATE_SCENE:
		GameDraw();
		break;

	case FINISH_UPDATE_SCENE:
		FinishDraw();
		break;

	default:
		break;
	}
}