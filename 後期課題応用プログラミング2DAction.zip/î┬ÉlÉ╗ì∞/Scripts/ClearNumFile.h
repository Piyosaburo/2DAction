#pragma once
#include <stdio.h>
#include "Macros.h"

extern int LoadClearNum();
extern void SaveClearNum(int);

