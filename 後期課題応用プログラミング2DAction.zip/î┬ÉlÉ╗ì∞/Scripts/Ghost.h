#pragma once
#include "DxLib.h"
#include "BasicInformation.h"
#include "Macros.h"

class Ghost :public CharacterBasicInformation {
private:
	int image;
	VECTOR imageSize;
	bool rota;
public:
	bool LoadTexture(const char*);
	void Init(bool,VECTOR);
	void Update(VECTOR);
	void Draw(VECTOR);
};