#pragma once
#include "GameScene.h"
#include "Player.h"
#include "Map.h"
#include "UI.h"
#include "GetItemEffect.h"
#include "Ghost.h"
#include "BackGround.h"

int stageNum;

UI ui;

Camera camera;

Player player;

Ghost ghost;

GetItemEffect getItemEffect[3];

BackGround background;

Map map;


float timeLimit;
int startTime;

int gameState;

int pauseSelectNum;

bool pushedEscapeKey;

float deltaTime;
float nowTime;

bool GameInit(int s) {

	stageNum = s;

	gameState = GAME_PLAY;

	pushedEscapeKey = false;

	pauseSelectNum = 0;

	nowTime = GetNowCount();
	deltaTime = 0;

	if (ui.LoadTexture("Images/Item.png","Images/ClearText.png","Images/DieText.png") == false) {
		return false;
	}

	ui.Init();

	VECTOR p = { 0,0 };

	camera.Init(p, MAP_X_NUM * MAPCHIP_SIZE);

	if (player.LoadTexture("Images/char.png") == false) {
		return false;
	}
	p = { PLAYER_START_POSITION_X,PLAYER_START_POSITION_Y };
	player.Init(true,p,stageNum);


	p = {0,0 };

	if (ghost.LoadTexture("Images/Ghost.png") == false) {
		return false;
	}

	if (stageNum == STAGE2) {
		ghost.Init(true, p);
	}
	else {
		ghost.Init(false, p);
	}

	for (int i = 0; i < 3; i++) {

		getItemEffect[i].Init(false);
	}

	if (map.LoadTexture("Images/MapChip.png") == false) {
		return false;
	}

	p = { 0,0 };
	map.Init(stageNum,p);

	if (background.LoadTexture("Images/BackGround.png", "Images/Foreground.png") == false) {
		return false;
	}
	background.Init(stageNum);

	return true;
}

int GameUpdate() {


	if (gameState == GAME_PLAY) {

		//play

		map.Update();

		player.Update(&map, &camera, getItemEffect,ghost.GetPos(), &gameState);

		ghost.Update(player.GetPos());

		for (int i = 0; i < 3; i++) {
			getItemEffect[i].Update(player.GetPos());
		}

		camera.Update();

		ui.Update(timeLimit);

	}
	else if (gameState == GAME_CLEAR || gameState == GAME_OVER) {

		if (GetAsyncKeyState(VK_RETURN) && pushedEnterKey == false) {

			pushedEnterKey = true;

			if (gameState == GAME_CLEAR) {
				SaveClearNum(stageNum + 1);
				return START_INIT_SCENE;
			}
			else if (gameState == GAME_OVER) {
				return START_INIT_SCENE;
			}
		}

		if (!GetAsyncKeyState(VK_RETURN)) {
			pushedEnterKey = false;
		}

	}
	else{ //�ꎞ��~

		if (GetAsyncKeyState(VK_UP) && pushedUpKey == false) {
			pauseSelectNum--;
			pushedUpKey = true;
		}
		if (!GetAsyncKeyState(VK_UP)) {
			pushedUpKey = false;
		}

		if (GetAsyncKeyState(VK_DOWN) && pushedDownKey == false) {
			pauseSelectNum++;
			pushedDownKey = true;
		}
		if (!GetAsyncKeyState(VK_DOWN)) {
			pushedDownKey = false;
		}

		if (pauseSelectNum < 0) {
			pauseSelectNum = 1;
		}

		if (pauseSelectNum > 1) {
			pauseSelectNum = 0;
		}

		if (GetAsyncKeyState(VK_RETURN) && pushedEnterKey == false) {
			pushedEnterKey = true;

			if (pauseSelectNum == 0) {
				gameState = GAME_PLAY; //�Q�[���ĊJ
			}
			else if (pauseSelectNum == 1) {
				return START_INIT_SCENE;
			}
		}

		if (!GetAsyncKeyState(VK_RETURN)) {
			pushedEnterKey = false;
		}
	}


	if (GetAsyncKeyState(VK_ESCAPE) && pushedEscapeKey == false) {

		pushedEscapeKey = true;

		if (gameState == GAME_PLAY) {
			gameState = GAME_PAUSE; //�ꎞ��~
		}
	}

	if (!GetAsyncKeyState(VK_ESCAPE)) {
		pushedEscapeKey = false;
	}

	deltaTime = (GetNowCount() - nowTime) / 1000.0f;
	nowTime = GetNowCount();

	return GAME_UPDATE_SCENE;
}

void GameDraw() {

	background.BackGroundDraw();
	map.Draw(camera.GetPos());
	player.Draw(camera.GetPos());
	ghost.Draw(camera.GetPos());

	for (int i = 0; i < 3; i++) {
		getItemEffect[i].Draw(camera.GetPos());
	}

	background.ForeGroundDraw();

	ui.Draw(player.GetHaveItemNum(),gameState,pauseSelectNum);

}